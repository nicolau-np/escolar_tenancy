create view view_estudante as
  select `e`.`id_estudante`     AS `id_estudante`,
         `p`.`nome`             AS `nome`,
         `p`.`genero`           AS `genero`,
         `p`.`idade`            AS `idade`,
         `p`.`data_nascimento`  AS `data_nascimento`,
         `ens`.`ensino`         AS `ensino`,
         `c`.`nome_curso`       AS `nome_curso`,
         `cl`.`classe`          AS `classe`,
         `t`.`turma`            AS `turma`,
         `e`.`data_cadastro`    AS `data_cadastro`,
         `e`.`data_modificacao` AS `data_modificacao`,
         `e`.`estadoE`          AS `estadoE`,
         `e`.`ano_lectivo`      AS `ano_lectivo`
  from (((((`tenancyschool_pa004598`.`tbl_estudante` `e` join `tenancyschool_pa004598`.`tbl_pessoa` `p` on ((
    `e`.`id_pessoa` = `p`.`id_pessoa`))) join `tenancyschool_pa004598`.`tbl_curso` `c` on ((`e`.`id_curso` =
                                                                                            `c`.`id_curso`))) join `tenancyschool_pa004598`.`tbl_classe` `cl` on ((
    `e`.`id_classe` = `cl`.`id_classe`))) join `tenancyschool_pa004598`.`tbl_turma` `t` on ((`e`.`id_turma` =
                                                                                             `t`.`id_turma`))) join `tenancyschool_pa004598`.`tbl_ensino` `ens` on ((
    `c`.`id_ensino` = `ens`.`id_ensino`)));


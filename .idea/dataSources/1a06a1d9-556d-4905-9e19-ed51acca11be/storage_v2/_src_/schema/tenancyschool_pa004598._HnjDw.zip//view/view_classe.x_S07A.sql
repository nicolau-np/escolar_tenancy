create view view_classe as
  select `cl`.`id_classe` AS `id_classe`,
         `cl`.`id_curso`  AS `id_curso`,
         `cl`.`classe`    AS `classe`,
         `c`.`nome_curso` AS `nome_curso`
  from (`tenancyschool_pa004598`.`tbl_classe` `cl` join `tenancyschool_pa004598`.`tbl_curso` `c` on ((`cl`.`id_curso` =
                                                                                                      `c`.`id_curso`)));


create view view_salas as
  select `s`.`id_sala`          AS `id_sala`,
         `t`.`tipo`             AS `tipo`,
         `s`.`quant_estudantes` AS `quant_estudantes`,
         `s`.`designacao`       AS `designacao`
  from (`tenancyschool_pa004598`.`tbl_sala` `s` join `tenancyschool_pa004598`.`tbl_tiposala` `t` on ((`s`.`id_tiposala`
                                                                                                      =
                                                                                                      `t`.`id_tiposala`)));


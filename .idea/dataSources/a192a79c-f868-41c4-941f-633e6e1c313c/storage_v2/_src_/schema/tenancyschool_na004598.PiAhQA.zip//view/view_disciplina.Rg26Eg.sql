create view view_disciplina as
  select `d`.`id_disciplina`   AS `id_disciplina`,
         `d`.`nome_disciplina` AS `nome_disciplina`,
         `d`.`sigla`           AS `sigla`,
         `c`.`componente`      AS `componente`
  from (`tenancyschool_na004598`.`tbl_disciplina` `d` join `tenancyschool_na004598`.`tbl_componente` `c` on ((
    `d`.`id_componente` = `c`.`id_componente`)));


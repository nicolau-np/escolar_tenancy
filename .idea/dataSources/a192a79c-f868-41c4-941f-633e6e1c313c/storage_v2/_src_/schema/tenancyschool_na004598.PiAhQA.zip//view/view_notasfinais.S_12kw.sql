create view view_notasfinais as
  select `nt`.`id_notasfinais`  AS `id_notasfinais`,
         `e`.`id_estudante`     AS `id_estudante`,
         `d`.`id_disciplina`    AS `id_disciplina`,
         `p`.`nome`             AS `nome`,
         `p`.`genero`           AS `genero`,
         `p`.`idade`            AS `idade`,
         `t`.`turma`            AS `turma`,
         `d`.`nome_disciplina`  AS `nome_disciplina`,
         `d`.`sigla`            AS `sigla`,
         `nt`.`cap`             AS `cap`,
         `nt`.`cpe`             AS `cpe`,
         `nt`.`cf`              AS `cf`,
         `nt`.`estado`          AS `estado`,
         `nt`.`data_lancamento` AS `data_lancamento`,
         `nt`.`ano_lectivo`     AS `ano_lectivo`
  from ((((`tenancyschool_na004598`.`tbl_notasfinais` `nt` join `tenancyschool_na004598`.`tbl_estudante` `e` on ((
    `nt`.`id_estudante` = `e`.`id_estudante`))) join `tenancyschool_na004598`.`tbl_turma` `t` on ((`e`.`id_turma` =
                                                                                                   `t`.`id_turma`))) join `tenancyschool_na004598`.`tbl_pessoa` `p` on ((
    `p`.`id_pessoa` = `e`.`id_pessoa`))) join `tenancyschool_na004598`.`tbl_disciplina` `d` on ((`nt`.`id_disciplina` =
                                                                                                 `d`.`id_disciplina`)));


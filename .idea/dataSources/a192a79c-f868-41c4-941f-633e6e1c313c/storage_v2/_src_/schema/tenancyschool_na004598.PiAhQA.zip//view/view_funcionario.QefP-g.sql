create view view_funcionario as
  select `f`.`id_funcionario`   AS `id_funcionario`,
         `p`.`nome`             AS `nome`,
         `p`.`genero`           AS `genero`,
         `p`.`comuna`           AS `comuna`,
         `c`.`cargo`            AS `cargo`,
         `e`.`nome_escalao`     AS `nome_escalao`,
         `f`.`agente`           AS `agente`,
         `f`.`data_cadastro`    AS `data_cadastro`,
         `f`.`data_modificacao` AS `data_modificacao`,
         `f`.`estadoF`          AS `estadoF`
  from (((`tenancyschool_na004598`.`tbl_funcionario` `f` join `tenancyschool_na004598`.`tbl_pessoa` `p` on ((
    `f`.`id_pessoa` = `p`.`id_pessoa`))) join `tenancyschool_na004598`.`tbl_escalao` `e` on ((`f`.`id_escalao` =
                                                                                              `e`.`id_escalao`))) join `tenancyschool_na004598`.`tbl_cargo` `c` on ((
    `f`.`id_cargo` = `c`.`id_cargo`)));


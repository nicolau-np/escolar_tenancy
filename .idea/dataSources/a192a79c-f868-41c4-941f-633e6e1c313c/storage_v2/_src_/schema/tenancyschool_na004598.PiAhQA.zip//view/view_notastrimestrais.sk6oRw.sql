create view view_notastrimestrais as
  select `nt`.`id_notastrimestrais` AS `id_notastrimestrais`,
         `e`.`id_estudante`         AS `id_estudante`,
         `d`.`id_disciplina`        AS `id_disciplina`,
         `p`.`nome`                 AS `nome`,
         `p`.`genero`               AS `genero`,
         `p`.`idade`                AS `idade`,
         `t`.`turma`                AS `turma`,
         `d`.`nome_disciplina`      AS `nome_disciplina`,
         `d`.`sigla`                AS `sigla`,
         `nt`.`epoca`               AS `epoca`,
         `nt`.`mac`                 AS `mac`,
         `nt`.`cpp`                 AS `cpp`,
         `nt`.`ct`                  AS `ct`,
         `nt`.`data_lancamento`     AS `data_lancamento`,
         `nt`.`ano_lectivo`         AS `ano_lectivo`
  from ((((`tenancyschool_na004598`.`tbl_notastrimestrais` `nt` join `tenancyschool_na004598`.`tbl_estudante` `e` on ((
    `nt`.`id_estudante` = `e`.`id_estudante`))) join `tenancyschool_na004598`.`tbl_turma` `t` on ((`e`.`id_turma` =
                                                                                                   `t`.`id_turma`))) join `tenancyschool_na004598`.`tbl_pessoa` `p` on ((
    `p`.`id_pessoa` = `e`.`id_pessoa`))) join `tenancyschool_na004598`.`tbl_disciplina` `d` on ((`nt`.`id_disciplina` =
                                                                                                 `d`.`id_disciplina`)));


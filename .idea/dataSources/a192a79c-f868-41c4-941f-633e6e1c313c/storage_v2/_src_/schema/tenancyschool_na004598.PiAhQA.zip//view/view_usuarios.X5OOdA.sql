create view view_usuarios as
  select `u`.`id_usuario`     AS `id_usuario`,
         `f`.`id_funcionario` AS `id_funcionario`,
         `f`.`agente`         AS `agente`,
         `u`.`nome_usuario`   AS `nome_usuario`,
         `u`.`estado`         AS `estado_us`,
         `s`.`senha`          AS `senha`,
         `c`.`cargo`          AS `cargo`,
         `p`.`nome`           AS `nome`,
         `p`.`genero`         AS `genero`,
         `p`.`idade`          AS `idade`,
         `p`.`telefone`       AS `telefone`,
         `pro`.`provincia`    AS `provincia`,
         `m`.`municipio`      AS `municipio`
  from ((((((`tenancyschool_na004598`.`tbl_pessoa` `p` join `tenancyschool_na004598`.`tbl_funcionario` `f` on ((
    `p`.`id_pessoa` = `f`.`id_pessoa`))) join `tenancyschool_na004598`.`tbl_usuario` `u` on ((`f`.`id_funcionario` =
                                                                                              `u`.`id_funcionario`))) join `tenancyschool_na004598`.`tbl_cargo` `c` on ((
    `f`.`id_cargo` = `c`.`id_cargo`))) join `tenancyschool_na004598`.`tbl_senha` `s` on ((`u`.`id_usuario` =
                                                                                          `s`.`id_usuario`))) join `tenancyschool_na004598`.`tbl_provincia` `pro` on ((
    `p`.`id_provincia` = `pro`.`id_provincia`))) join `tenancyschool_na004598`.`tbl_municipio` `m` on ((
    `p`.`id_municipio` = `m`.`id_municipio`)));


create view view_turma as
  select `t`.`id_turma`   AS `id_turma`,
         `t`.`turma`      AS `turma`,
         `e`.`ensino`     AS `ensino`,
         `c`.`nome_curso` AS `nome_curso`,
         `cl`.`classe`    AS `classe`,
         `tu`.`turno`     AS `turno`
  from ((((`tenancyschool_pa004598`.`tbl_turma` `t` join `tenancyschool_pa004598`.`tbl_curso` `c` on ((`t`.`id_curso` =
                                                                                                       `c`.`id_curso`))) join `tenancyschool_pa004598`.`tbl_classe` `cl` on ((
    `t`.`id_classe` = `cl`.`id_classe`))) join `tenancyschool_pa004598`.`tbl_turno` `tu` on ((`t`.`id_turno` =
                                                                                              `tu`.`id_turno`))) join `tenancyschool_pa004598`.`tbl_ensino` `e` on ((
    `e`.`id_ensino` = `c`.`id_ensino`)));


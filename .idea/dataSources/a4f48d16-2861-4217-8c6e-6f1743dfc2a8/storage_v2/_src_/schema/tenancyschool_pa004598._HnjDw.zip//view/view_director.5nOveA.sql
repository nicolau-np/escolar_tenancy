create view view_director as
  select `dir`.`id_director`   AS `id_director`,
         `f`.`id_funcionario`  AS `id_funcionario`,
         `p`.`nome`            AS `nome`,
         `p`.`data_nascimento` AS `data_nascimento`,
         `p`.`genero`          AS `genero`,
         `f`.`agente`          AS `agente`,
         `ens`.`ensino`        AS `ensino`,
         `cur`.`nome_curso`    AS `nome_curso`,
         `cl`.`classe`         AS `classe`,
         `t`.`id_turma`        AS `id_turma`,
         `t`.`turma`           AS `turma`,
         `tur`.`turno`         AS `turno`,
         `dir`.`ano_lectivo`   AS `ano_lectivo`
  from (((((((`tenancyschool_pa004598`.`tbl_director` `dir` join `tenancyschool_pa004598`.`tbl_funcionario` `f` on ((
    `dir`.`id_funcionario` = `f`.`id_funcionario`))) join `tenancyschool_pa004598`.`tbl_pessoa` `p` on ((`p`.`id_pessoa`
                                                                                                         =
                                                                                                         `f`.`id_pessoa`))) join `tenancyschool_pa004598`.`tbl_turma` `t` on ((
    `dir`.`id_turma` = `t`.`id_turma`))) join `tenancyschool_pa004598`.`tbl_curso` `cur` on ((`t`.`id_curso` =
                                                                                              `cur`.`id_curso`))) join `tenancyschool_pa004598`.`tbl_classe` `cl` on ((
    `t`.`id_classe` = `cl`.`id_classe`))) join `tenancyschool_pa004598`.`tbl_ensino` `ens` on ((`cur`.`id_ensino` =
                                                                                                `ens`.`id_ensino`))) join `tenancyschool_pa004598`.`tbl_turno` `tur` on ((
    `t`.`id_turno` = `tur`.`id_turno`)));


create view view_prova as
  select `pr`.`id_prova`       AS `id_prova`,
         `e`.`id_estudante`    AS `id_estudante`,
         `d`.`id_disciplina`   AS `id_disciplina`,
         `p`.`nome`            AS `nome`,
         `p`.`genero`          AS `genero`,
         `p`.`idade`           AS `idade`,
         `t`.`turma`           AS `turma`,
         `d`.`nome_disciplina` AS `nome_disciplina`,
         `d`.`sigla`           AS `sigla`,
         `pr`.`epoca`          AS `epoca`,
         `pr`.`valor1`         AS `valor1`,
         `pr`.`data_valor1`    AS `data_valor1`,
         `pr`.`valor2`         AS `valor2`,
         `pr`.`data_valor2`    AS `data_valor2`,
         `pr`.`ano_lectivo`    AS `ano_lectivo`
  from ((((`tenancyschool_pa004598`.`tbl_prova` `pr` join `tenancyschool_pa004598`.`tbl_estudante` `e` on ((
    `pr`.`id_estudante` = `e`.`id_estudante`))) join `tenancyschool_pa004598`.`tbl_disciplina` `d` on ((
    `pr`.`id_disciplina` = `d`.`id_disciplina`))) join `tenancyschool_pa004598`.`tbl_pessoa` `p` on ((`e`.`id_pessoa` =
                                                                                                      `p`.`id_pessoa`))) join `tenancyschool_pa004598`.`tbl_turma` `t` on ((
    `e`.`id_turma` = `t`.`id_turma`)));


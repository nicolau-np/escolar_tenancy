create view view_avaliacao as
  select `a`.`id_avaliacao`    AS `id_avaliacao`,
         `e`.`id_estudante`    AS `id_estudante`,
         `d`.`id_disciplina`   AS `id_disciplina`,
         `p`.`nome`            AS `nome`,
         `p`.`genero`          AS `genero`,
         `p`.`idade`           AS `idade`,
         `t`.`turma`           AS `turma`,
         `d`.`nome_disciplina` AS `nome_disciplina`,
         `d`.`sigla`           AS `sigla`,
         `a`.`epoca`           AS `epoca`,
         `a`.`valor1`          AS `valor1`,
         `a`.`data_valor1`     AS `data_valor1`,
         `a`.`valor2`          AS `valor2`,
         `a`.`data_valor2`     AS `data_valor2`,
         `a`.`valor3`          AS `valor3`,
         `a`.`data_valor3`     AS `data_valor3`,
         `a`.`ano_lectivo`     AS `ano_lectivo`
  from ((((`tenancyschool_pa004598`.`tbl_avaliacao` `a` join `tenancyschool_pa004598`.`tbl_estudante` `e` on ((
    `a`.`id_estudante` = `e`.`id_estudante`))) join `tenancyschool_pa004598`.`tbl_disciplina` `d` on ((
    `a`.`id_disciplina` = `d`.`id_disciplina`))) join `tenancyschool_pa004598`.`tbl_pessoa` `p` on ((`e`.`id_pessoa` =
                                                                                                     `p`.`id_pessoa`))) join `tenancyschool_pa004598`.`tbl_turma` `t` on ((
    `e`.`id_turma` = `t`.`id_turma`)));


create view view_permicaousuario as
  select `peru`.`id_permicaousuario` AS `id_permicaousuario`,
         `peru`.`id_usuario`         AS `id_usuario`,
         `tperu`.`tipo`              AS `tipo`
  from (`tenancyschool_pa004598`.`tbl_permicaousuario` `peru` join `tenancyschool_pa004598`.`tbl_tipopermicao` `tperu` on ((
    `peru`.`id_tipopermicao` = `tperu`.`id_tipopermicao`)));


create view view_hora as
  select `h`.`id_hora`      AS `id_hora`,
         `t`.`turno`        AS `turno`,
         `h`.`hora_entrada` AS `hora_entrada`,
         `h`.`hora_saida`   AS `hora_saida`
  from (`tenancyschool_pa004598`.`tbl_hora` `h` join `tenancyschool_pa004598`.`tbl_turno` `t` on ((`h`.`id_turno` =
                                                                                                   `t`.`id_turno`)));


create view view_disccurso as
  select `disc`.`id_disccurso`  AS `id_disccurso`,
         `disc`.`id_disciplina` AS `id_disciplina`,
         `c`.`nome_curso`       AS `nome_curso`,
         `cl`.`classe`          AS `classe`,
         `d`.`nome_disciplina`  AS `nome_disciplina`,
         `d`.`sigla`            AS `sigla`,
         `epd`.`tipo`           AS `tipo`
  from ((((`tenancyschool_pa004598`.`tbl_disccurso` `disc` join `tenancyschool_pa004598`.`tbl_curso` `c` on ((
    `disc`.`id_curso` = `c`.`id_curso`))) join `tenancyschool_pa004598`.`tbl_disciplina` `d` on ((`disc`.`id_disciplina`
                                                                                                  =
                                                                                                  `d`.`id_disciplina`))) join `tenancyschool_pa004598`.`tbl_classe` `cl` on ((
    `disc`.`id_classe` = `cl`.`id_classe`))) join `tenancyschool_pa004598`.`tbl_epocadis` `epd` on ((
    `disc`.`id_epocaDis` = `epd`.`id_epocaDis`)));


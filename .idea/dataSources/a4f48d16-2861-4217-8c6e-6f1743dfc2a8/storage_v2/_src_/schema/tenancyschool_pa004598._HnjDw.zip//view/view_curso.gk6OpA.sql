create view view_curso as
  select `c`.`id_curso` AS `id_curso`, `c`.`nome_curso` AS `nome_curso`, `e`.`ensino` AS `ensino`
  from (`tenancyschool_pa004598`.`tbl_curso` `c` join `tenancyschool_pa004598`.`tbl_ensino` `e` on ((`c`.`id_ensino` =
                                                                                                     `e`.`id_ensino`)));

